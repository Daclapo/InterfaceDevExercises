﻿Module Module1
    Sub Main()
        ' Iniciar la aplicación con Form1
        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)
        Application.Run(New Form1())
    End Sub
End Module
